<?php 
    require "../database.php";		

    if (isset($_GET['dId'])) {
        $dId = $_GET['dId'];
        $del = $pdo->prepare("DELETE FROM research WHERE researchId = '$dId'");
        $del->execute();
        echo '<script type="text/javascript"> alert("Research Conference removed successfully."); </script>';;
        header('refresh:2;url=index.php');
    }

 ?>

 <?php 
 		$con=mysqli_connect("localhost","root","","researchs");
 		define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/php/research/');
		define('SITE_PATH','');

		function get_safe_value($con,$str){
			if($str!=''){
				$str=trim($str);
				return mysqli_real_escape_string($con,$str);
			}
		}

    if(isset($_GET['type']) && $_GET['type']!=''){
				$type=get_safe_value($con,$_GET['type']);
				if($type=='status'){
					$operation=get_safe_value($con,$_GET['operation']);
					$id=get_safe_value($con,$_GET['id']);
					if($operation=='active'){
						$status='0';
					}else{
						$status='1';
					}
					$update_status_sql="update research set status='$status' where researchId='$id'";
					mysqli_query($con,$update_status_sql);
				}
				
			}

		$sql="select * from research order by researchId asc";
		$res=mysqli_query($con,$sql);
  ?>




<!Doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="../homepage.css">
<link rel="stylesheet" href="../style.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 
 
<title> Astra app </title>
</head>

<body>
<header>
		<div class="header">
		<a href="index.php"> <img src="../logo.png" alt="logo loading" width="111" Height="111"> </a>
		<div class="logout">
		<a class="lgo" href="index.php">Research Paper</a>
		<a class="lgo" href="contact.php">Contact Users</a>
		</div>
		  </div>
		  </header>


<section>
	<div class="container">
		<div class="first">
			<div class="flex">
				<div class="right">
					<div style="padding: 20px 5px 20px 5px;">
						<div class="det">
							<h2>Research Conference</h2>
						</div>
						<div style="overflow-x:auto;">
						<table id="customers" >
						  <tr>
						    <th>Research Title</th>
						    <th>Location</th>
						    <th>Published By</th>
						    <th>File Name</th>
						    <th>Operation</th>
						  </tr>
						  <?php while($row=mysqli_fetch_assoc($res)){ 
						  echo '<tr>';
						   echo '<td>'.$row['title'].'</td>';
						   echo '<td>'.$row['location'].'</td>';
						   echo '<td>'.$row['submitted_by'].'</td>';
						   echo '<td>'.$row['filename'].'</td>';
						   echo '<td style="display: flex; border:none; line-height:85px;">';
								
								if($row['status']==0){
									echo "<span class='btna'><a href='?type=status&operation=deactive&id=".$row['researchId']."'>Approved</a></span>&nbsp;";
								}else{
									echo "<span class='btnd'><a href='?type=status&operation=active&id=".$row['researchId']."'>Disapproved</a></span>&nbsp;";
								}
								
								echo '<span class="btnr"><a class="btn" href="index.php?dId='.$row['researchId'].'">Delete</a></span>';
								
							   echo '</td>'; ?>
							 <td style="float: left; border:none;">
							   	<a class="btn btn-warning" <?php echo 'href="../docdetails.php?detal='.$row['researchId'].'"';?> target="_blank">view file</a>
							   <a class="dow" href="uploads/<?php echo $row['filename']; ?>" download>Download</a>
							</td>
						<!-- 	  <td>
						   	
						   </td> -->
						    
						  <?php echo '</tr>';
						 } ?>
						</table>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


</body>
</html>  