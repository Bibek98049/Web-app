



Follow the instruction:

First of all, you need to copy paste the file (research file) and paste it to (xampp htdocs folder). Then you can find the researchs.sql file in data inside the research data folder. Create researchs database in the xampp and import in xampp. For import, you need to click on the researchs database link and you will find a navbar that contain import, export, privilege, operation, etc. Go to import link and there is section called choose file and then choose researchs.sql file which is given. Then go to browser and type (localhost/research). You can view you website. For accessing the upload and view section, you need to login by given username and password. Don't forget that you have two section in this website one is admin and one is users. The above browser link is use for users but the admin access is different. for admin access type (localhost/research/admin). For the admin section, you can approve the post, delete, view, and download. without admin approve the you have not access to view on the viewsreport section. 

For the upload section, user need some struggle like to find the location longitude and latitude. For accessing the longitude and latitude of the location go to google map and which location you want to upload then simple click on the map by targeting the location pinpoint is appeared and you can view the latitude and longitude. The first one is latitude and the second one is longitude copy and paste on the field. While uploading the research paper you can only upload pdf file not other that is already mention on the design section. If you upload the doc file it cann't view and download. The map is used for know about the previous location which is uploaded. But the location pinpoint is only appear when the admin approve you document. The location marker will appear after the submission of file not during the submission. 

