<div id="myDIV">
  <a href="index.php" class="btns active">1</a>
  <a href="addconference.php" class="btns">2</ a>
  <a class="btns">3</a>
  <a class="btns">4</a>
</div>