<!Doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="forgotpw.css">
<title> Astra app </title>
</head>

<body>
<div class="loginbox">
<h1> Reset new password </h1>
<form>
<label id="newpw" <b>Choose new password</b></label>
<input type="text" placeholder="Enter new password" name="newpw" required >
<br> <label id="confirm new psw" <b>Confirm new password</b></label>
<input type="text" placeholder="Confirm new password" name="Confirm new psw" required >
<input type="submit" name="sub" value="Login"> <br>

</form>
</div>

</body>
</html>  