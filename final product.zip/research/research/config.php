<?php 
	
	$server     = 'localhost';
	$username   = 'root';
	$password   = '';
	$database   = 'researchs';

	$dsn        = "mysql:host=$server;dbname=$database";

 ?>